# generate_report.py

def make_report(
        repo_name,
        code_report):
    
    similarity = code_report.get("code_similarity", 0)
    bugs = code_report.get("bugs", [])
    efficiency_score = code_report.get("efficiency_score", 0)
    suggestions = code_report.get("suggestions", [])
    score = efficiency_score * 100

    report = f"""
# {repo_name}

## Overall Score

{score}/100

## Code Analysis

### Code Similarity
{similarity}%

### Bugs Found
{', '.join(bugs) if bugs else 'None'}

### Efficiency Score
{efficiency_score}/100

### Suggestions
{', '.join(suggestions) if suggestions else 'None'}

---"""


    with open(
        f"reports/{repo_name}.md",
        "w",
        encoding="utf8"
    ) as f:

        f.write(report)