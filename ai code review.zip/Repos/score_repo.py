# score_repo.py

def compute_score(code_similarity,
                  output_similarity,
                  efficiency_score):

    total = (
        0.3*code_similarity
        +0.5*output_similarity
        +0.2*efficiency_score
    )

    return round(total,2)