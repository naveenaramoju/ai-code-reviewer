# clone_repos.py

import pandas as pd
import subprocess
from pathlib import Path

df = pd.read_csv("repos.csv")

save_dir = Path("student_repos")
save_dir.mkdir(exist_ok=True)

for url in df["repo_url"]:
    repo_name = url.split("/")[-2]

    target = save_dir / repo_name

    if target.exists():
        continue

    subprocess.run(
        ["git", "clone", url, str(target)],
        check=False
    )