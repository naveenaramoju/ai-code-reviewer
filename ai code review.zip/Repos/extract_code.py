# extract_code.py

import nbformat
from pathlib import Path


def extract_repository_code(repo_path):

    combined_code = []

    for file in Path(repo_path).rglob("*"):

        if file.suffix == ".py":

            try:
                combined_code.append(file.read_text(errors="ignore"))
            except:
                pass

        elif file.suffix == ".ipynb":

            try:
                nb = nbformat.read(file, as_version=4)

                for cell in nb.cells:

                    if cell.cell_type == "code":
                        combined_code.append(cell.source)

            except:
                pass

    return "\n\n".join(combined_code)