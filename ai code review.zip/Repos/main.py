import pandas as pd

from extract_code import extract_repository_code
from compare_code import compare_code
from score_repo import compute_score
from generate_report import make_report

reference_code = extract_repository_code(
    "reference/code"
)

df = pd.read_csv("repos.csv")

for url in df.repo_url:

    repo_name = url.split("/")[-2]

    student_code = extract_repository_code(
        f"student_repos/{repo_name}"
    )
    print("Initialised........")


    code_report = compare_code(
        reference_code,
        student_code
    )

    make_report(
        repo_name,
        code_report
    )