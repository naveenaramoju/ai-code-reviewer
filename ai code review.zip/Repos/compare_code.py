# compare_code.py

import json

import ollama
import requests

def compare_code(reference_code, student_code):

    prompt = f"""
    You are a Code evaluating Agent. Your task is to compare the reference implementation with the student implementation and provide a detailed evaluation.
Just compare reference and student code. Do not provide any extra text or explanations. Only return the JSON object as specified below.

Focus more on Variable names , code structure understandability, efficiency and also prompts used (enchance them if needed).

Reference RAG implementation:

{reference_code}

--------------------------------

Student implementation:

{student_code}


Compare both implementations.

Return JSON:

{{
 "code_similarity":0,
 "bugs":[],
 "efficiency_score":0,
 "suggestions":[]
}}
Just follow strict rules no extra text, no explanations just follow strictly the JSON format and return only the JSON object.
"""
    print("Comparing code...")

    # response = ollama.chat(
    #     model="llama3:8b",
    #     messages=[{"role": "user", "content": prompt}],
    #     stream = True
    # )
    import json

    url = "https://myai.ganiisunkara.workers.dev"

    headers = {
        "Authorization": "Bearer 12345678",
        "Content-Type": "application/json",
    }

    data = {
        "prompt": prompt,
    }

    response = requests.post(url, headers=headers, json=data)
    res = response.json()

    print("LLM RAW RESPONSE:")
    print(res)

    # Extract model output
    model_output = res["response"]

    # Remove markdown fences if present
    model_output = (
        model_output
        .replace("```json", "")
        .replace("```", "")
        .strip()
    )

    try:
        code_report = json.loads(model_output)

    except json.JSONDecodeError as e:
        print("JSON parsing failed:")
        print(model_output)

        code_report = {
            "code_similarity": 0,
            "bugs": [f"JSON parsing error: {e}"],
            "efficiency_score": 0,
            "suggestions": []
        }

    return code_report